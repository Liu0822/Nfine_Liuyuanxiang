<template lang="pug" src='./index.pug'></template>

<script>
export default {
  name: 'Loading'
}
</script>

<style lang="sass" scoped src='./index.sass'>
</style>
