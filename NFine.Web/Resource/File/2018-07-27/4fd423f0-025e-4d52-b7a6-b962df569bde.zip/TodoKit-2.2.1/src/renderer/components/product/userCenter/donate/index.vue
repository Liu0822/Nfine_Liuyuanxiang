<template lang="pug" src='./index.pug'>

</template>

<script>
export default {
  name: 'ProductUserProfile'
}
</script>

<style lang="sass" scoped src='./index.sass'>
</style>
